import Layout from '../dashboard/layout';
export default Layout;